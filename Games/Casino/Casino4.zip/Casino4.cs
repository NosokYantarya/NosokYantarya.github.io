using System;
using System.Collections.Generic;
using System.Linq;

class qqq
{
    static Random rand = new Random();
	static bool play = true;
	static int money = 1000;
	static string[] slotnames =
	{
		"Eggplant",
		"Lemon",
		"Crouton",
		"A4",
		"Snus",
		"Plasma"
	};
	static int[] slotprizes =
	{
		1000,
		1000,
		1000,
		-1000,
		5000,
		10000
	};
	static int[] slots =
	{
		rand.Next(0,6),
		rand.Next(0,6),
		rand.Next(0,6)
	};
	static int[] wheel =
	{
	    0,
	    1,
	    0,
	    1,
	    0,
	    1,
	    0,
	    2
	};
	static string[] wheelnames =
	{
	    "Ленин",
	    "Сталин",
	    "Темми"
	};
	static int[] wheelprizes =
	{
	    500,
	    1000,
	    10000
	};
	static int[] wheelloses =
	{
	    100,
	    250,
	    500
	};
	static string[,] crates=
	{
	    {
	        "Перцовка",
	        "Хирик",
	        "Бронежилет Кальвин Кляйна",
	        "Яйцо фаберже",
	        "Солнечные очки",
	        "Крестик",
	        "Зелёные Кальвин Кляйны",
	        "Клей Master Klein"
	    },
	    {
	        "Дубина Романиуса",
	        "Иксрос",
	        "Бронежилет Романиуса",
	        "Ромовая кислота",
	        "Дубина Романиуса +",
	        "Книга Белиала",
	        "Яйцо",
	        "Лосось Алексей"
	    },
	    {
	        "♂Bondage♂",
	        "♂Leather glove♂",
	        "♂Next door♂",
	        "♂300 bucks♂",
	        "Футболка ♂Boss of this gym♂",
	        "♂Fucking slave♂",
	        "Маска ♂dungeon master♂",
	        "Ключ от ♂dungeon♂"
	    }
	};
	public static string[] inventory =
	{
	    "Пусто",
	    "Пусто",
	    "Пусто",
	    "Пусто",
	    "Пусто",
	    "Пусто",
	    "Пусто",
	    "Пусто",
	    "Пусто",
	    "Пусто"
	};
	public static int[] chance =
	{
	    20,
	    40,
	    60,
	    70,
	    80,
	    90,
	    95,
	    100
	};
	public static string crateprize;
	public static int[,] prices =
	{
	    {10,300},
	    {10,300},
	    {10,300},
	    {200,500},
	    {200,500},
	    {200,500},
	    {500,1000},
	    {500,1000}
	};
	public static int randomdeal;
	public static int[,] offers = new int[10,3];
	
	public static void Main()
	{
		
		
		while(play==true)
		{
		    Start:
		    Console.WriteLine("Выберите действие (Слоты, Колесо, Магазин, Рынок, Выйти).");
		    switch(Console.ReadLine())
		    {
		        case "Слоты":
		            while(true)
		            {
		                Console.WriteLine("Баланс: {0}.", money);
		                Console.WriteLine("Выберите действие (Играть, Выход).");
		                switch(Console.ReadLine())
		                {
		                    case "Играть":
		                        Slots();
		                        break;
		                    case "Выход":
		                        goto Start;
		                }
		            }
		            break;
		        case "Колесо":
		            WheelStart:
		            while(true)
		            {
		                Console.WriteLine("Баланс: {0}.", money);
		                Console.WriteLine("Выберите действие (Играть, Выход).");
		                switch(Console.ReadLine())
		                {
		                    case "Играть":
		                        while(true)
		                        {
		                            Console.WriteLine("Введите ставку (Ленин, Сталин, Темми).");
		                            switch(Console.ReadLine())
		                            {
		                                case "Ленин":
		                                    Wheel(0);
		                                    goto WheelStart;
		                                case "Сталин":
		                                    Wheel(1);
		                                    goto WheelStart;
		                                case "Темми":
		                                    Wheel(2);
		                                    goto WheelStart;
		                            }
		                        }
		                        break;
		                    case "Выход":
		                        goto Start;
		                }
		            }
		            break;
		        case "Магазин":
		            BuyStart:
		            while(true)
		            {
		                Console.WriteLine("Баланс: {0}.", money);
		                Console.WriteLine("Выбедите действие (Купить, Удалить, Выйти).");
		                switch(Console.ReadLine())
		                {
		                    case "Купить":
		                        while(true)
		                        {
		                            Console.WriteLine("Выберите кейс (Кальвин, Роман, Dungeon).");
		                            switch(Console.ReadLine())
		                            {
		                                case "Кальвин":
		                                    Buy(0);
		                                    goto BuyStart;
		                                case "Роман":
		                                    Buy(1);
		                                    goto BuyStart;
		                                case "Dungeon":
		                                    Buy(2);
		                                    goto BuyStart;
		                            }
		                        }
		                        break;
		                    case "Удалить":
		                        while(true)
		                        {
		                            Console.WriteLine("Введите номер предмета, который надо удалить.");
		                            for(int i = 0; i<10; i++)
		                            {
		                                Console.WriteLine("{0}. {1}", i+1, inventory[i]);
		                            }
		                            int delnum = Convert.ToInt32(Console.ReadLine());
		                            if(delnum>0 && delnum<11)
                                    {
                                        inventory[delnum-1] = "Пусто";
                                        break;
                                    }
		                        }
		                        break;
		                    case "Выйти":
		                        goto Start;
		                }
		            }
		            break;
		        case "Рынок":
		            SellStart:
		            while(true)
		            {
		                Console.WriteLine("Баланс: {0}.", money);
		                Console.WriteLine("Инвентарь:");
		                for(int i = 0; i<10; i++)
		                {
		                    Console.WriteLine("{0}. {1}", i+1, inventory[i]);
		                }
		                Console.WriteLine("Предложения:");
		                for(int i = 0; i!=10; i++)
		                {
		                    Console.WriteLine("{0}. {1} за {2} православных рублей.", i+1, crates[offers[i,0],offers[i,1]], offers[i,2]);
		                }
		                Console.WriteLine("Выберите действие (Продать, Поменять, Выход).");
		                switch(Console.ReadLine())
		                {
		                    case "Продать":
		                        Console.WriteLine("Введите номер предложения.");
		                        Sell(Convert.ToInt32(Console.ReadLine())-1);
		                        goto SellStart;
		                    case "Поменять":
		                        money-=50;
		                        for(int i = 0; i!=10; i++)
	                            {
	                                randomdeal=rand.Next(0,8);
	                                offers[i,0] = rand.Next(0,3);
	                                offers[i,1] = randomdeal; 
	                                offers[i,2] = rand.Next(prices[randomdeal,0],prices[randomdeal,1]);
	                            }
	                            goto SellStart;
		                    case "Выход":
		                        goto Start;
		                        
		                }
		            }
		            break;
		        case "Выход":
		            play = false;
		            break;
		    }
		}
	}
	public static void Slots()
	{
	    slots = new int[]
		{
			rand.Next(0,6),
			rand.Next(0,6),
			rand.Next(0,6)
		};
		Console.WriteLine("{0} {1} {2}", slotnames[slots[0]], slotnames[slots[1]], slotnames[slots[2]]);
		if(slots[0]==slots[1] && slots[0]==slots[2])
		{
		    money+=slotprizes[slots[0]];
		    Console.WriteLine("Поздравляем, вы выиграли {0} православных рублей!", slotprizes[slots[0]]);
		}
		else
		{
		    money-=100;
		    Console.WriteLine("Вы проиграли 100 православных рублей.");
		}
	}
	public static void Wheel(int Bet)
	{
	    for(int i = rand.Next(0,8); i!=7; i++)
	    {
	        var temp = wheel[wheel.Length-1];    
            Array.Copy(wheel, 0, wheel, 1, wheel.Length - 1);
            wheel[0] = temp;
	    }
	    Console.WriteLine("{0} {1} {2} {3} {4} {5} {6} {7}", wheelnames[wheel[0]], wheelnames[wheel[1]], wheelnames[wheel[2]], wheelnames[wheel[3]], wheelnames[wheel[4]], wheelnames[wheel[5]], wheelnames[wheel[6]], wheelnames[wheel[7]]);
	    Console.WriteLine("^");
	    if(wheel[0]==Bet)
	    {
	        money+=wheelprizes[Bet];
	        Console.WriteLine("Поздравляем, вы выиграли {0} православных рублей!", wheelprizes[Bet]);
	    }
	    else
	    {
	        money-=wheelloses[Bet];
	        Console.WriteLine("Вы проиграли {0} православных рублей.", wheelloses[Bet]);
	    }
	}
    public static void Buy(int buynum)
    {
        money-=20;
        int randomitem = rand.Next(0,100);
        for(int i = 0; i!=8; i++)
        {
            if(randomitem<chance[i])
            {
                crateprize = crates[buynum, i];
                break;
            }
        }
        for(int i = 0; i!=10; i++)
        {
            if (inventory[i]=="Пусто")
            {
                inventory[i] = crateprize;
                break;
            }
        }
        Console.WriteLine("Вы получили {0}.", crateprize);
    }
    public static void Sell(int sellnum)
    {
        if(sellnum<0 || sellnum>9)
        {
            return;
        }
        for(int i = 0; i<=10; i++)
        {
            if(inventory[i]==crates[offers[sellnum,0],offers[sellnum,1]])
            {
                money+=offers[sellnum,2];
                inventory[i]="Пусто";
                Console.WriteLine("Вы продали ваш {0} за {1} православных рублей.", inventory[i], offers[sellnum,2]);
                break;
            }
            if(i==10)
            {
                Console.WriteLine("Вы не обладаете этим предметом.");
            }
        }
    }
}