local mod = RegisterMod("churka", 1)

local game = Game()
local ModItems = {
	RomaAcid = Isaac.GetItemIdByName("Ромовая кислота"),
	RomaEssence = Isaac.GetItemIdByName("Лудомания"),
	Iksros = Isaac.GetItemIdByName("Иксрос"),
	Trusy = Isaac.GetItemIdByName("Зелёные Кальвин Кляйны"),
	Sunglass = Isaac.GetItemIdByName("Очки Егора"),
	Coin = Isaac.GetItemIdByName("Зарплата"),
	Egg = Isaac.GetItemIdByName("Яйцо фаберже")
}
local Stats = {}

local RomaAcidDamage = 1
local RomaEssenceDamage = 0.3
local IksrosDamage = 0.5
local IksrosCount = 0
function mod:EvaluateCache(player, cacheFlags)
	
    if cacheFlags & CacheFlag.CACHE_DAMAGE == CacheFlag.CACHE_DAMAGE then
        local itemCount = player:GetCollectibleNum(ModItems.RomaAcid)
        local damageToAdd = RomaAcidDamage * itemCount
        player.Damage = player.Damage + damageToAdd
		
		player.Damage = player.Damage + IksrosDamage * IksrosCount
    end
	
	if cacheFlags & CacheFlag.CACHE_LUCK == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(ModItems.RomaEssence) then
			player.Damage = player.Damage + (player.Luck-Stats.Luck) * RomaEssenceDamage
			Stats.Luck = player.Luck
		end
	end
end
mod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, mod.EvaluateCache)

function mod:OnTear(tear)
	local player = Isaac.GetPlayer(0)
	
end
mod:AddCallback(ModCallbacks.MC_POST_TEAR_INIT, mod.OnTear)

function mod:OnTearUpdate(tear)
	local player = Isaac.GetPlayer(0)
	if player:HasCollectible(ModItems.Sunglass) then
		if tear.FrameCount % 10 == 0 then
			Isaac.Spawn(1000, 19, 0, tear.Position, Vector(0,0), player)
		end
	end
	if tear and not tear:HasTearFlags(TearFlags.TEAR_POISON) and player:HasCollectible(ModItems.RomaAcid) then
        tear:AddTearFlags(TearFlags.TEAR_POISON)
		tear.Color = Color(0, 1, 0, 1)
	end
	if tear and not tear:HasTearFlags(TearFlags.TEAR_PIERCING) and player:HasCollectible(ModItems.Sunglass) then
        tear:AddTearFlags(TearFlags.TEAR_PIERCING)
	end
end
mod:AddCallback(ModCallbacks.MC_POST_TEAR_UPDATE, mod.OnTearUpdate)

function mod:OnActiveUse(item)
	local player = Isaac.GetPlayer(0)
	if item == ModItems.Iksros then
		if player:GetHearts()>0 then
			player:AddMaxHearts(-2,false)
			IksrosCount = IksrosCount + 1
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		end
		return {
			Discharge = true,
			Remove = false,
			ShowAnim = true
		}
	end
	if item == ModItems.Trusy then
		CanUseTrusy = false
		player:UseActiveItem(483)
		return {
			Discharge = true,
			Remove = false,
			ShowAnim = true
		}
	end
	if item == ModItems.Egg then
		local rndm = Random() % 100
		if rndm<46 then
			Isaac.Spawn(5, 10, 4, player.Position, Vector(0,0), player)
		end
		if 91>rndm and rndm>45 then
			Isaac.Spawn(5, 10, 3, player.Position, Vector(0,0), player)
			Isaac.Spawn(5, 10, 3, player.Position, Vector(0,0), player)
		end
		if rndm>90 then
			local pool = game:GetItemPool()
			Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_COLLECTIBLE, pool:GetCollectible(ItemPoolType.POOL_ANGEL, true, Random(), CollectibleType.COLLECTIBLE_HOLY_GRAIL), player.Position, Vector(0,0), player)
		end
		return {
			Discharge = true,
			Remove = false,
			ShowAnim = true
		}
	end
end
mod:AddCallback(ModCallbacks.MC_USE_ITEM, mod.OnActiveUse)

local CoinIDs = {1,24,49,50,51,52,126,131,147,172}
local SpawnedCoin = false
function mod:OnPickup(pickup)
	player = Isaac.GetPlayer(0)
	if pickup.Variant == PickupVariant.PICKUP_COLLECTIBLE and pickup.SubType == ModItems.Coin and SpawnedCoin == false then
		SpawnedCoin = true
		Isaac.Spawn(5, 350, CoinIDs[Random() % 10 + 1], player.Position, Vector(0,0), player)
	end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.OnPickup)

function mod:OnStart()
	local player = Isaac.GetPlayer(0)
	Stats = {
		FireDelay = player.FireDelay,
		MaxFireDelay = player.MaxFireDelay,
		Damage = player.Damage,
		TearRange = player.TearRange,
		ShotSpeed = player.ShotSpeed,
		Luck = player.Luck
	}
	
	IksrosCount = 0
	SpawnedCoin = false
end
mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, mod.OnStart)