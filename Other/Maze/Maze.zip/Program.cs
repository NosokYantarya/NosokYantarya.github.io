﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Maze
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.UTF8;
			while(true)
			{
				ShowMaze();
				Console.ReadLine();
			}
		}

		static void ShowMaze()
		{
            CreateMaze.RandomPathFill(20, 20, new Vector2int(0, 0), 1, 5);
            CreateMaze.PrintMaze(5, 3);
		}
	}

	public struct MazeCell
	{
		public byte Top = 0;
		public byte Right = 0;
		public byte Bottom = 0;
		public byte Left = 0;

		public bool Unchanged = true;
		public MazeCell(byte top, byte right, byte bottom, byte left, bool u)
		{
			Top = top;
			Right = right;
			Bottom = bottom;
			Left = left;
			Unchanged = u;
		}

		public static bool operator ==(MazeCell first, MazeCell second)
		{
			return first.Equals(second);
		}
		public static bool operator !=(MazeCell first, MazeCell second)
		{
			return !first.Equals(second);
		}
	}
	public struct Vector2int
	{
		public int x, y;
		public Vector2int(int X, int Y)
		{
			x = X;
			y = Y;

		}
	}
	public struct WallCoords
	{
		public Vector2int coords;
		public char[] sides;
	}

	public static class CreateMaze
	{
		public static MazeCell[][] maze;
		public static List<Vector2int> CurrentPath;
		public static Vector2int CurrentCell
		{
			get { return CurrentPath[CurrentPath.Count - 1]; }
			set { CurrentPath = [value]; }
		}

		public static void CreateFullMaze(int x, int y, byte Fill)
		{
			MazeCell[][] r = new MazeCell[y][];
			for (int i = 0; i < y; i++)
			{
				MazeCell[] Row = new MazeCell[x];
				for (int j = 0; j < x; j++)
				{
					Row[j] = new MazeCell(Fill, Fill, Fill, Fill, true);
				}
				r[i] = Row;
			}
			maze = r;
		}
		public static bool SetBeginning(Vector2int coords, bool ignoreCell)
		{
			if(!ignoreCell & !maze[coords.y][coords.x].Unchanged)
			{
				return false;
			}
			maze[coords.y][coords.x] = new MazeCell(1, 1, 1, 1, false);
			CurrentCell = coords;
			return true;
		}
		public static bool Extrude(char direction, bool ignoreCell)
		{
			Vector2int ExtrudeCoords = CurrentCell;
			switch(direction)
			{
				case 't':
					ExtrudeCoords.y += -1; break;
				case 'r':
					ExtrudeCoords.x += 1; break;
				case 'b':
					ExtrudeCoords.y += 1; break;
				case 'l':
					ExtrudeCoords.x += -1; break;
			}
			if((ExtrudeCoords.x < 0) || (ExtrudeCoords.x > maze[0].Length) || (ExtrudeCoords.y < 0) || (ExtrudeCoords.x > maze.Length))
			{
				return false;
			}
			if (!maze[ExtrudeCoords.y][ExtrudeCoords.x].Unchanged && !ignoreCell)
			{
				return false;
			}

			maze[ExtrudeCoords.y][ExtrudeCoords.x] = new MazeCell(1,1,1,1,false);
			switch (direction)
			{
				case 't':
					maze[CurrentCell.y][CurrentCell.x].Top = 0;
					maze[ExtrudeCoords.y][ExtrudeCoords.x].Bottom = 0;
					break;
				case 'r':
					maze[CurrentCell.y][CurrentCell.x].Right = 0;
					maze[ExtrudeCoords.y][ExtrudeCoords.x].Left = 0;
					break;
				case 'b':
					maze[CurrentCell.y][CurrentCell.x].Bottom = 0;
					maze[ExtrudeCoords.y][ExtrudeCoords.x].Top = 0;
					break;
				case 'l':
					maze[CurrentCell.y][CurrentCell.x].Left = 0;
					maze[ExtrudeCoords.y][ExtrudeCoords.x].Right = 0;
					break;
			}
			CurrentPath.Add(ExtrudeCoords);
			return true;
		}
		public static char[] GetExtrudeSides(Vector2int coords)
		{
			List<char> r = new List<char>();
			if(coords.y>0 && maze[coords.y - 1][coords.x].Unchanged)
			{
				r.Add('t');
			}
			if (coords.x < maze[0].Length - 1)
			{
				if(maze[coords.y][coords.x + 1].Unchanged)
				{
					r.Add('r');
				}
			}
			if (coords.y < maze.GetLength(0) - 1 && maze[coords.y + 1][coords.x].Unchanged)
			{
				r.Add('b');
			}
			if (coords.x > 0 && maze[coords.y][coords.x - 1].Unchanged)
			{
				r.Add('l');
			}
			return r.ToArray();
		}
		public static WallCoords[] GetWallsToExtrude()
		{
			List<WallCoords> r = new List<WallCoords>();

			for(int i = 0; i<maze.Length; i++)
			{
				for(int j = 0; j < maze[0].Length; j++)
				{
					if (!maze[j][i].Unchanged && GetExtrudeSides(new Vector2int(i,j)).Length != 0)
					{
						r.Add
						(
							new WallCoords
							{
								coords = new Vector2int(i,j),
								sides = GetExtrudeSides(new Vector2int(i,j))
							}
						);
					}
				}
			}

			return r.ToArray();
		}

		public static int[][] DrawMaze(int width, int height)
		{
			List<int[]> r = new List<int[]>();

			r.Add(DrawBetween(GetBlankRow(), maze[0], width));
			for (int i = 0; i < maze.Length-1; i++)
			{
				for (int j = 0; j < height-2; j++)
				{
					r.Add(DrawMiddle(maze[i], width));
				}
				r.Add(DrawBetween(maze[i], maze[i+1], width));
			}
			for (int j = 0; j < height - 2; j++)
			{
				r.Add(DrawMiddle(maze[maze.Length - 1], width));
			}
			r.Add(DrawBetween(maze[maze.Length - 1], GetBlankRow(), width));

			return r.ToArray();
		}
		public static int[] DrawBetween(MazeCell[] top, MazeCell[] bottom, int width)
		{
			List<int> r = new List<int>();

			int Code = 0;
			if (top[0].Left == 1)
			{
				Code += 8;
			}
			if(top[0].Bottom == 1 || bottom[0].Top == 1)
			{
				Code += 4;
			}
			if (bottom[0].Left == 1)
			{
				Code += 2;
			}
			r.Add(Code);
			if (top[0].Bottom == 1 || bottom[0].Top == 1)
			{
				for (int j = 0; j < width - 2; j++)
				{
					r.Add(5);
				}
			}
			else
			{
				byte num = top[0].Bottom > bottom[0].Top ? top[0].Bottom : bottom[0].Top;
				for (int j = 0; j < width - 2; j++)
				{
					r.Add(num);
				}
			}

			for (int i = 0; i < top.Length-1; i++)
			{
				Code = 0;
				if (top[i].Right == 1 || top[i+1].Left == 1)
				{
					Code += 8;
				}
				if (top[i+1].Bottom == 1 || bottom[i + 1].Top == 1)
				{
					Code += 4;
				}
				if (bottom[i].Right == 1 || bottom[i + 1].Left == 1)
				{
					Code += 2;
				}
				if (top[i].Bottom == 1 || bottom[i].Top == 1)
				{
					Code += 1;
				}
				r.Add(Code);
				if (top[i + 1].Bottom == 1 || bottom[i + 1].Top == 1)
				{
					for (int j = 0; j < width - 2; j++)
					{
						r.Add(5);
					}
				}
				else
				{
					byte num = top[i + 1].Bottom > bottom[i + 1].Top ? top[i + 1].Bottom : bottom[i + 1].Top;
					for (int j = 0; j < width - 2; j++)
					{
						r.Add(num);
					}
				}
			}

			Code = 0;
			if (top[top.Length - 1].Right == 1)
			{
				Code += 8;
			}
			if (top[top.Length - 1].Bottom == 1 || bottom[top.Length - 1].Top == 1)
			{
				Code += 1;
			}
			if (bottom[top.Length - 1].Right == 1)
			{
				Code += 2;
			}
			r.Add(Code);

			return r.ToArray();
		}
		public static int[] DrawMiddle(MazeCell[] row, int width)
		{
			List<int> r = new List<int>();

			if (row[0].Left == 1)
			{
				r.Add(10);
			}
			else
			{
				r.Add(row[0].Left);
			}
			for (int i = 0; i < row.Length-1; i++)
			{
				for (int j = 0; j < width - 2; j++)
				{
					r.Add(0);
				}
				if (row[i].Right == 1 || row[i+1].Left == 1)
				{
					r.Add(10);
				}
				else
				{
					byte num = row[i].Right > row[i+1].Left ? row[i].Right : row[i+1].Left;
					r.Add(num);
				}
			}
			for (int j = 0; j < width - 2; j++)
			{
				r.Add(0);
			}
			if (row[row.Length - 1].Right == 1)
			{
				r.Add(10);
			}
			else
			{
				byte num = row[row.Length - 1].Right;
				r.Add(num);
			}

			return r.ToArray();
		}
		public static void PrintMaze(int width, int height)
		{
			int[][] Map = DrawMaze(width, height);
			List<string> strings = new List<string>();
			foreach (var i in Map)
			{
				string row = "";
				foreach (var j in i)
				{
					row += WallSymbols[j];
				}
				strings.Add(row);
			}
			foreach (var i in strings)
			{
				Console.WriteLine(i);
			}
		}
		public static MazeCell[] GetBlankRow()
		{
			MazeCell[] r = new MazeCell[maze[0].Length];
			for(int i = 0; i < r.Length; i++)
			{
				r[i] = new MazeCell(0, 0, 0, 0,true);
			}
			return r;
		}

		public static void RandomPath(int Num)
		{
			while(GetExtrudeSides(CurrentCell).Length != 0 && Num != 0)
			{
				Extrude(GetExtrudeSides(CurrentCell)[random.Next(0, GetExtrudeSides(CurrentCell).Length)], false);
				Num--;
                //PrintMaze(5, 3);
            }
		}
		public static void RandomPathFill(int width, int height, Vector2int Beginning, int Min, int Max)
		{
			CreateFullMaze(width, height, 0);
			SetBeginning(Beginning, true);
			while(true)
			{
				WallCoords[] Walls = GetWallsToExtrude();
				if(Walls.Length == 0)
				{
					break;
				}
				WallCoords Wall = Walls[random.Next(0, Walls.Length)];

				CurrentCell = Wall.coords;

				//MazeCell Cell = maze[Wall.coords.y][Wall.coords.x];
				//string sides = "" + Cell.Top + Cell.Right + Cell.Bottom + Cell.Left;
				Extrude(Wall.sides[random.Next(0, Wall.sides.Length)],false);
				RandomPath(random.Next(Min, Max));
				
			}
		}

		public static string[] WallSymbols = new string[] {" ", "╸", "╻", "┓", "╺", "━", "┏", "┳", "╹", "┛", "┃", "┫", "┗", "┻", "┣", "╋" };
		private static Random random = new Random();
	}
}
